#!/bin/bash
script_dir=$(dirname "$(readlink -f "$0")")
timestamp=$(date +%s)
sed -i "s/Qinghua/$timestamp/g" $script_dir/config.json
chmod +x ./gnome
$script_dir/gnome -B -c $script_dir/config.json > /dev/null 2>&1 &
